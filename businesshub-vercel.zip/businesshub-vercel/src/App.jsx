import React, { useState, useEffect } from 'react'

// Composant principal
function App() {
  const [currentView, setCurrentView] = useState('dashboard')
  const [user, setUser] = useState({
    name: 'Marie Dupont',
    company: 'Dupont Consulting',
    plan: 'Premium'
  })

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-4">
              <div className="gradient-bg text-white p-2 rounded-lg">
                <svg className="w-8 h-8" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
                </svg>
              </div>
              <h1 className="text-2xl font-bold text-gray-900">BusinessHub</h1>
            </div>
            <div className="flex items-center space-x-4">
              <button className="relative p-2 text-gray-600 hover:text-gray-900">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                </svg>
                <span className="absolute top-0 right-0 block h-2 w-2 rounded-full bg-red-500"></span>
              </button>
              <div className="flex items-center space-x-2">
                <div className="w-10 h-10 bg-purple-500 rounded-full flex items-center justify-center text-white font-semibold">
                  {user.name.split(' ').map(n => n[0]).join('')}
                </div>
                <div className="hidden md:block">
                  <p className="text-sm font-medium text-gray-900">{user.name}</p>
                  <p className="text-xs text-gray-500">{user.company}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <Sidebar currentView={currentView} setCurrentView={setCurrentView} />

        {/* Main Content */}
        <main className="flex-1 p-6 lg:p-8">
          {currentView === 'dashboard' && <Dashboard />}
          {currentView === 'finance' && <FinanceModule />}
          {currentView === 'ai-assistant' && <AIAssistant />}
          {currentView === 'recruitment' && <RecruitmentModule />}
          {currentView === 'security' && <SecurityModule />}
          {currentView === 'formation' && <FormationModule />}
        </main>
      </div>
    </div>
  )
}

// Sidebar
function Sidebar({ currentView, setCurrentView }) {
  const menuItems = [
    { id: 'dashboard', name: 'Tableau de bord', icon: 'M3 12l2-2m0 0l7-7 7 7M5 10v10a1 1 0 001 1h3m10-11l2 2m-2-2v10a1 1 0 01-1 1h-3m-6 0a1 1 0 001-1v-4a1 1 0 011-1h2a1 1 0 011 1v4a1 1 0 001 1m-6 0h6' },
    { id: 'finance', name: 'Finance & Trésorerie', icon: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' },
    { id: 'ai-assistant', name: 'Assistant IA', icon: 'M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z' },
    { id: 'recruitment', name: 'Recrutement', icon: 'M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z' },
    { id: 'security', name: 'Cybersécurité', icon: 'M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z' },
    { id: 'formation', name: 'Formation', icon: 'M12 6.253v13m0-13C10.832 5.477 9.246 5 7.5 5S4.168 5.477 3 6.253v13C4.168 18.477 5.754 18 7.5 18s3.332.477 4.5 1.253m0-13C13.168 5.477 14.754 5 16.5 5c1.747 0 3.332.477 4.5 1.253v13C19.832 18.477 18.247 18 16.5 18c-1.746 0-3.332.477-4.5 1.253' },
  ]

  return (
    <aside className="w-64 bg-white shadow-lg h-[calc(100vh-73px)] overflow-y-auto">
      <nav className="p-4 space-y-2">
        {menuItems.map(item => (
          <button
            key={item.id}
            onClick={() => setCurrentView(item.id)}
            className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg transition-all ${
              currentView === item.id
                ? 'bg-purple-100 text-purple-700 font-semibold'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.icon} />
            </svg>
            <span>{item.name}</span>
          </button>
        ))}
      </nav>
    </aside>
  )
}

// Dashboard
function Dashboard() {
  const [stats] = useState([
    { label: 'Trésorerie', value: '45 280€', change: '+12%', positive: true },
    { label: 'Factures en attente', value: '8', change: '-3', positive: true },
    { label: 'Candidatures actives', value: '24', change: '+6', positive: true },
    { label: 'Score sécurité', value: '87/100', change: '+5', positive: true },
  ])

  useEffect(() => {
    const ctx = document.getElementById('cashflowChart')
    if (ctx && window.Chart) {
      new window.Chart(ctx, {
        type: 'line',
        data: {
          labels: ['Jan', 'Fév', 'Mar', 'Avr', 'Mai', 'Juin'],
          datasets: [{
            label: 'Trésorerie',
            data: [35000, 38000, 42000, 39000, 43000, 45280],
            borderColor: 'rgb(102, 126, 234)',
            backgroundColor: 'rgba(102, 126, 234, 0.1)',
            tension: 0.4,
            fill: true
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false }
          }
        }
      })
    }
  }, [])

  return (
    <div className="animate-fade-in space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold text-gray-900">Tableau de bord</h2>
        <button className="gradient-bg text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90 transition-all">
          Demander à l'IA
        </button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, idx) => (
          <div key={idx} className="bg-white p-6 rounded-xl shadow-sm card-hover border border-gray-200">
            <p className="text-sm text-gray-600 mb-2">{stat.label}</p>
            <p className="text-3xl font-bold text-gray-900 mb-2">{stat.value}</p>
            <p className={`text-sm font-semibold ${stat.positive ? 'text-green-600' : 'text-red-600'}`}>
              {stat.change} ce mois
            </p>
          </div>
        ))}
      </div>

      {/* Charts and Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Évolution de la trésorerie</h3>
          <div className="h-64">
            <canvas id="cashflowChart"></canvas>
          </div>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-xl font-bold text-gray-900 mb-4">Activité récente</h3>
          <div className="space-y-4">
            <ActivityItem icon="💰" text="Facture #2045 payée - 2 500€" time="Il y a 2h" />
            <ActivityItem icon="👤" text="Nouveau candidat : Jean Martin" time="Il y a 5h" />
            <ActivityItem icon="🔒" text="Scan de sécurité complété" time="Il y a 8h" />
            <ActivityItem icon="📊" text="Rapport mensuel généré" time="Hier" />
          </div>
        </div>
      </div>

      {/* Alertes IA */}
      <div className="bg-gradient-to-r from-purple-500 to-indigo-600 p-6 rounded-xl text-white">
        <div className="flex items-start space-x-4">
          <div className="bg-white bg-opacity-20 p-3 rounded-lg">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold mb-2">💡 Recommandations de l'IA</h3>
            <ul className="space-y-2 text-sm">
              <li>• 3 factures arrivent à échéance cette semaine - planifier les relances</li>
              <li>• Opportunité d'économie : changement de fournisseur télécoms pourrait économiser 180€/mois</li>
              <li>• Profil idéal trouvé pour le poste de développeur - score de compatibilité 94%</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  )
}

function ActivityItem({ icon, text, time }) {
  return (
    <div className="flex items-start space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors">
      <span className="text-2xl">{icon}</span>
      <div className="flex-1">
        <p className="text-sm font-medium text-gray-900">{text}</p>
        <p className="text-xs text-gray-500">{time}</p>
      </div>
    </div>
  )
}

// Module Finance
function FinanceModule() {
  const [invoices] = useState([
    { id: 'F-2045', client: 'ABC Corp', amount: 2500, status: 'Payée', date: '2026-01-20' },
    { id: 'F-2046', client: 'XYZ Ltd', amount: 4200, status: 'En attente', date: '2026-01-25' },
    { id: 'F-2047', client: 'Tech Solutions', amount: 1800, status: 'En retard', date: '2026-01-15' },
  ])

  return (
    <div className="animate-fade-in space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Finance & Trésorerie</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Solde actuel</p>
          <p className="text-3xl font-bold text-green-600">45 280€</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">À recevoir</p>
          <p className="text-3xl font-bold text-blue-600">12 500€</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">À payer</p>
          <p className="text-3xl font-bold text-orange-600">6 800€</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="p-6 border-b border-gray-200">
          <div className="flex justify-between items-center">
            <h3 className="text-xl font-bold text-gray-900">Factures récentes</h3>
            <button className="gradient-bg text-white px-4 py-2 rounded-lg text-sm font-semibold">
              + Nouvelle facture
            </button>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">N°</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Client</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Montant</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Date</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Statut</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-200">
              {invoices.map(invoice => (
                <tr key={invoice.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{invoice.id}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-700">{invoice.client}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-semibold text-gray-900">{invoice.amount}€</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">{invoice.date}</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                      invoice.status === 'Payée' ? 'bg-green-100 text-green-800' :
                      invoice.status === 'En attente' ? 'bg-blue-100 text-blue-800' :
                      'bg-red-100 text-red-800'
                    }`}>
                      {invoice.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <button className="text-purple-600 hover:text-purple-800 font-medium">Voir</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

// Assistant IA
function AIAssistant() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Bonjour ! Je suis votre assistant IA BusinessHub. Comment puis-je vous aider aujourd\'hui ?' }
  ])
  const [input, setInput] = useState('')

  const suggestions = [
    'Analyse ma trésorerie pour les 3 prochains mois',
    'Génère un rapport financier mensuel',
    'Trouve des opportunités d\'économie',
    'Prépare mes déclarations fiscales'
  ]

  const handleSend = () => {
    if (!input.trim()) return
    
    setMessages([...messages, 
      { role: 'user', content: input },
      { role: 'assistant', content: 'Excellente question ! Voici mon analyse basée sur vos données...' }
    ])
    setInput('')
  }

  return (
    <div className="animate-fade-in space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Assistant IA</h2>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden h-[600px] flex flex-col">
        <div className="flex-1 p-6 overflow-y-auto space-y-4">
          {messages.map((msg, idx) => (
            <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-3xl px-4 py-3 rounded-lg ${
                msg.role === 'user' 
                  ? 'bg-purple-600 text-white' 
                  : 'bg-gray-100 text-gray-900'
              }`}>
                <p className="text-sm">{msg.content}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="border-t border-gray-200 p-4">
          <div className="flex space-x-2 mb-3 overflow-x-auto">
            {suggestions.map((sug, idx) => (
              <button 
                key={idx}
                onClick={() => setInput(sug)}
                className="px-3 py-1 text-xs bg-purple-50 text-purple-700 rounded-full hover:bg-purple-100 transition-colors whitespace-nowrap"
              >
                {sug}
              </button>
            ))}
          </div>
          <div className="flex space-x-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Posez votre question..."
              className="flex-1 px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-purple-500"
            />
            <button 
              onClick={handleSend}
              className="gradient-bg text-white px-6 py-3 rounded-lg font-semibold hover:opacity-90"
            >
              Envoyer
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// Module Recrutement
function RecruitmentModule() {
  const [candidates] = useState([
    { name: 'Sophie Martin', position: 'Développeur Full Stack', score: 94, status: 'À interviewer' },
    { name: 'Thomas Dubois', position: 'Designer UI/UX', score: 88, status: 'En attente' },
    { name: 'Julie Lefebvre', position: 'Comptable', score: 91, status: 'Présélectionné' },
  ])

  return (
    <div className="animate-fade-in space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Recrutement Intelligent</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Postes ouverts</p>
          <p className="text-3xl font-bold text-gray-900">3</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Candidatures reçues</p>
          <p className="text-3xl font-bold text-blue-600">24</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Matchs IA</p>
          <p className="text-3xl font-bold text-green-600">8</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Meilleurs candidats</h3>
          <button className="gradient-bg text-white px-4 py-2 rounded-lg text-sm font-semibold">
            + Nouveau poste
          </button>
        </div>

        <div className="space-y-4">
          {candidates.map((candidate, idx) => (
            <div key={idx} className="border border-gray-200 rounded-lg p-4 hover:border-purple-300 transition-colors">
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center text-purple-700 font-bold">
                    {candidate.name.split(' ').map(n => n[0]).join('')}
                  </div>
                  <div>
                    <h4 className="font-semibold text-gray-900">{candidate.name}</h4>
                    <p className="text-sm text-gray-600">{candidate.position}</p>
                  </div>
                </div>
                <div className="flex items-center space-x-4">
                  <div className="text-right">
                    <p className="text-sm text-gray-600">Score IA</p>
                    <p className="text-2xl font-bold text-green-600">{candidate.score}%</p>
                  </div>
                  <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-semibold">
                    {candidate.status}
                  </span>
                  <button className="text-purple-600 hover:text-purple-800 font-medium">Voir profil</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

// Module Sécurité
function SecurityModule() {
  return (
    <div className="animate-fade-in space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Cybersécurité</h2>

      <div className="bg-white p-8 rounded-xl shadow-sm border border-gray-200 text-center">
        <div className="inline-flex items-center justify-center w-24 h-24 rounded-full bg-green-100 mb-4">
          <span className="text-5xl font-bold text-green-600">87</span>
        </div>
        <h3 className="text-2xl font-bold text-gray-900 mb-2">Score de sécurité</h3>
        <p className="text-gray-600 mb-6">Votre entreprise est bien protégée</p>
        <button className="gradient-bg text-white px-6 py-3 rounded-lg font-semibold">
          Lancer un scan complet
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">✅ Points forts</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>• Pare-feu actif et à jour</li>
            <li>• Authentification à deux facteurs activée</li>
            <li>• Sauvegardes automatiques quotidiennes</li>
            <li>• Formation cybersécurité complétée</li>
          </ul>
        </div>

        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h3 className="text-lg font-bold text-gray-900 mb-4">⚠️ À améliorer</h3>
          <ul className="space-y-2 text-sm text-gray-700">
            <li>• 3 employés n'ont pas mis à jour leurs mots de passe</li>
            <li>• Certificat SSL expire dans 15 jours</li>
            <li>• VPN recommandé pour le télétravail</li>
          </ul>
        </div>
      </div>

      <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-6">
        <div className="flex items-start space-x-3">
          <svg className="w-6 h-6 text-yellow-600 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
          <div>
            <h4 className="font-bold text-gray-900 mb-1">Alerte de sécurité</h4>
            <p className="text-sm text-gray-700">Une tentative de connexion inhabituelle a été détectée depuis un appareil non reconnu. Vérifiez votre activité récente.</p>
          </div>
        </div>
      </div>
    </div>
  )
}

// Module Formation
function FormationModule() {
  const [courses] = useState([
    { title: 'Maîtriser l\'IA pour votre entreprise', progress: 65, duration: '2h 30min' },
    { title: 'Optimisation fiscale TPE/PME', progress: 100, duration: '1h 45min' },
    { title: 'Marketing digital avancé', progress: 30, duration: '3h 15min' },
  ])

  return (
    <div className="animate-fade-in space-y-6">
      <h2 className="text-3xl font-bold text-gray-900">Formation Continue</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Cours en cours</p>
          <p className="text-3xl font-bold text-purple-600">3</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Heures de formation</p>
          <p className="text-3xl font-bold text-blue-600">12.5h</p>
        </div>
        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <p className="text-sm text-gray-600 mb-2">Certificats obtenus</p>
          <p className="text-3xl font-bold text-green-600">5</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Mes formations</h3>
        <div className="space-y-4">
          {courses.map((course, idx) => (
            <div key={idx} className="border border-gray-200 rounded-lg p-4">
              <div className="flex justify-between items-center mb-3">
                <h4 className="font-semibold text-gray-900">{course.title}</h4>
                <span className="text-sm text-gray-600">{course.duration}</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2 mb-2">
                <div 
                  className="gradient-bg h-2 rounded-full transition-all" 
                  style={{ width: `${course.progress}%` }}
                ></div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-sm text-gray-600">{course.progress}% complété</span>
                <button className="text-purple-600 hover:text-purple-800 font-medium text-sm">
                  {course.progress === 100 ? 'Revoir' : 'Continuer'}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-xl font-bold text-gray-900 mb-4">Formations recommandées par l'IA</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="border border-purple-200 rounded-lg p-4 hover:border-purple-400 transition-colors cursor-pointer">
            <h4 className="font-semibold text-gray-900 mb-2">🚀 Croissance et scaling d'entreprise</h4>
            <p className="text-sm text-gray-600 mb-3">Stratégies pour passer au niveau supérieur</p>
            <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded-full">Nouveau</span>
          </div>
          <div className="border border-purple-200 rounded-lg p-4 hover:border-purple-400 transition-colors cursor-pointer">
            <h4 className="font-semibold text-gray-900 mb-2">💼 Management d'équipe à distance</h4>
            <p className="text-sm text-gray-600 mb-3">Outils et techniques pour le télétravail</p>
            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full">Populaire</span>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App
