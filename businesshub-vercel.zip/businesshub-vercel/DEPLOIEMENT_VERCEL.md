# 🚀 Guide Complet - Déploiement BusinessHub sur Vercel

## Étape par Étape pour Débutants

### 📋 Prérequis

Avant de commencer, assurez-vous d'avoir :
- ✅ Un compte GitHub (gratuit sur github.com)
- ✅ Un compte Vercel (gratuit sur vercel.com)
- ✅ Git installé sur votre ordinateur
- ✅ Node.js installé (version 18+)

---

## 🎯 Partie 1 : Créer un Repository GitHub

### 1.1 Créer un nouveau repository

1. Allez sur https://github.com
2. Cliquez sur le bouton "+" en haut à droite
3. Sélectionnez "New repository"
4. Nommez-le : `businesshub`
5. Laissez-le **Public** (ou Private si vous préférez)
6. **NE PAS** cocher "Add a README file"
7. Cliquez sur "Create repository"

### 1.2 Uploader votre code

**Option A : Depuis votre terminal (recommandé)**

```bash
# 1. Naviguez dans le dossier du projet
cd /chemin/vers/businesshub-vercel

# 2. Initialisez Git
git init

# 3. Ajoutez tous les fichiers
git add .

# 4. Créez votre premier commit
git commit -m "Initial commit - BusinessHub"

# 5. Renommez la branche en 'main'
git branch -M main

# 6. Connectez au repository GitHub (remplacez VOTRE-USERNAME)
git remote add origin https://github.com/VOTRE-USERNAME/businesshub.git

# 7. Envoyez le code sur GitHub
git push -u origin main
```

**Option B : Upload via l'interface GitHub**

1. Sur la page de votre repository GitHub
2. Cliquez sur "uploading an existing file"
3. Glissez-déposez TOUS les fichiers du dossier `businesshub-vercel`
4. Cliquez sur "Commit changes"

---

## 🚀 Partie 2 : Déploiement sur Vercel

### 2.1 Connexion à Vercel

1. Allez sur https://vercel.com
2. Cliquez sur "Sign Up" ou "Login"
3. Choisissez "Continue with GitHub"
4. Autorisez Vercel à accéder à votre GitHub

### 2.2 Importer le projet

1. Une fois connecté, cliquez sur "Add New..."
2. Sélectionnez "Project"
3. Vercel affiche vos repositories GitHub
4. Trouvez "businesshub" et cliquez sur "Import"

### 2.3 Configurer le projet

Vercel détecte automatiquement que c'est un projet Vite. Vérifiez :

- **Framework Preset** : Vite
- **Root Directory** : `./` (racine)
- **Build Command** : `npm run build` ✅
- **Output Directory** : `dist` ✅
- **Install Command** : `npm install` ✅

**Ne changez rien si tout est correct !**

### 2.4 Déployer

1. Cliquez sur le bouton bleu "Deploy"
2. Attendez 1-2 minutes (vous verrez les logs de build)
3. ✅ Succès ! Votre site est en ligne

### 2.5 Obtenir votre URL

Vercel vous donne automatiquement une URL :
```
https://businesshub-xxxx.vercel.app
```

Copiez cette URL - c'est votre application BusinessHub en ligne ! 🎉

---

## 🌐 Partie 3 : Ajouter un Domaine Personnalisé (Optionnel)

### 3.1 Acheter un domaine

Si vous voulez `app.businesshub.io` au lieu de `businesshub-xxxx.vercel.app` :

1. Achetez un domaine sur :
   - Namecheap.com
   - GoDaddy.com
   - OVH.com
   - Google Domains

Exemple : `businesshub.io` (~12€/an)

### 3.2 Configurer le domaine dans Vercel

1. Dans votre projet Vercel, allez dans "Settings"
2. Cliquez sur "Domains"
3. Entrez votre domaine : `app.businesshub.io`
4. Cliquez sur "Add"

### 3.3 Configurer les DNS

Vercel vous donnera des instructions comme :

```
Type: CNAME
Name: app
Value: cname.vercel-dns.com
```

Allez chez votre registrar de domaine et ajoutez cet enregistrement DNS.

⏱️ Attendez 5-60 minutes pour la propagation DNS.

---

## 🔧 Partie 4 : Variables d'Environnement

### 4.1 Qu'est-ce que c'est ?

Les variables d'environnement stockent des clés secrètes (API, Stripe, etc.)

### 4.2 Ajouter les variables dans Vercel

1. Dans votre projet Vercel, allez dans "Settings"
2. Cliquez sur "Environment Variables"
3. Ajoutez ces variables :

**Variable 1 : VITE_WHOP_API_KEY**
- Name : `VITE_WHOP_API_KEY`
- Value : Votre clé API Whop (ex: `whop_xxxxxxxxxxxx`)
- Environment : Production, Preview, Development

**Variable 2 : VITE_STRIPE_PUBLIC_KEY**
- Name : `VITE_STRIPE_PUBLIC_KEY`
- Value : Votre clé publique Stripe (ex: `pk_live_xxxxxxxxxxxx`)
- Environment : Production, Preview, Development

4. Cliquez sur "Save"

### 4.3 Redéployer

Après avoir ajouté les variables :
1. Allez dans l'onglet "Deployments"
2. Cliquez sur les "..." à côté du dernier déploiement
3. Cliquez sur "Redeploy"

---

## 🔄 Partie 5 : Mettre à Jour l'Application

### 5.1 Faire des modifications localement

1. Éditez vos fichiers dans `src/App.jsx` ou autres
2. Testez localement : `npm run dev`

### 5.2 Pousser les changements sur GitHub

```bash
# 1. Ajoutez les fichiers modifiés
git add .

# 2. Créez un commit
git commit -m "Amélioration de l'interface"

# 3. Poussez sur GitHub
git push
```

### 5.3 Déploiement automatique

✨ **Magie Vercel** : Dès que vous poussez sur GitHub, Vercel redéploie automatiquement !

Regardez dans l'onglet "Deployments" de Vercel pour suivre le build.

---

## 📊 Partie 6 : Monitoring et Analytics

### 6.1 Voir les statistiques Vercel

Dans votre projet Vercel :
- **Analytics** : Visiteurs, pages vues, performances
- **Speed Insights** : Vitesse de chargement
- **Logs** : Erreurs et activité

### 6.2 Ajouter Google Analytics (optionnel)

1. Créez un compte Google Analytics
2. Obtenez votre ID de tracking (ex: `G-XXXXXXXXXX`)
3. Ajoutez dans `index.html` avant `</head>` :

```html
<!-- Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=G-XXXXXXXXXX"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());
  gtag('config', 'G-XXXXXXXXXX');
</script>
```

4. Commit et push

---

## 🛡️ Partie 7 : Sécurité et Performance

### 7.1 HTTPS automatique

✅ Vercel active HTTPS automatiquement (SSL gratuit)

### 7.2 Headers de sécurité

Créez un fichier `vercel.json` à la racine :

```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-XSS-Protection",
          "value": "1; mode=block"
        }
      ]
    }
  ]
}
```

### 7.3 Optimisation des images

Vercel optimise automatiquement :
- ✅ Compression
- ✅ Format WebP
- ✅ Lazy loading

---

## 🔍 Partie 8 : Debugging et Résolution de Problèmes

### 8.1 Le build échoue

**Erreur : "Module not found"**

Solution :
```bash
# Vérifiez que toutes les dépendances sont installées
npm install
npm run build
```

**Erreur : "Build exceeded maximum duration"**

Solution : Votre build prend trop de temps. Simplifiez ou divisez en plusieurs déploiements.

### 8.2 L'application est blanche après le déploiement

**Vérifiez dans les logs Vercel** :
1. Onglet "Deployments"
2. Cliquez sur le déploiement
3. Regardez les "Build Logs"
4. Cherchez les erreurs en rouge

**Solution commune** : Chemins d'import incorrects
- Vérifiez que tous les `import` utilisent les bons chemins
- Les chemins sont sensibles à la casse sur Vercel !

### 8.3 Les variables d'environnement ne fonctionnent pas

Assurez-vous :
1. ✅ Qu'elles commencent par `VITE_` (important pour Vite)
2. ✅ Qu'elles sont dans "Production" environment
3. ✅ Que vous avez redéployé après les avoir ajoutées

---

## ✅ Checklist Finale

Avant de lancer publiquement :

- [ ] Build passe sans erreur
- [ ] Application accessible via l'URL Vercel
- [ ] Tous les modules fonctionnent (Finance, IA, Recrutement, etc.)
- [ ] Design responsive (testez sur mobile)
- [ ] Variables d'environnement configurées
- [ ] Domaine personnalisé configuré (optionnel)
- [ ] Analytics activé (optionnel)
- [ ] Testé sur Chrome, Firefox, Safari

---

## 🎉 Félicitations !

Votre plateforme BusinessHub est maintenant en ligne et accessible au monde entier !

**Prochaines étapes** :
1. Intégrez avec Whop pour les paiements
2. Ajoutez l'authentification utilisateur
3. Connectez une vraie base de données
4. Lancez votre marketing !

## 🆘 Besoin d'Aide ?

- 📧 Email : support@businesshub.io
- 💬 Discord Vercel : vercel.com/discord
- 📚 Documentation Vercel : vercel.com/docs

---

**Bon lancement ! 🚀**
