# BusinessHub - Plateforme SaaS

Plateforme tout-en-un pour gérer votre entreprise avec IA, finance, recrutement et cybersécurité.

## 🚀 Déploiement sur Vercel

### Méthode 1 : Déploiement depuis GitHub (Recommandé)

1. **Créer un repository GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   git remote add origin https://github.com/VOTRE-USERNAME/businesshub.git
   git push -u origin main
   ```

2. **Connecter à Vercel**
   - Allez sur https://vercel.com
   - Cliquez sur "New Project"
   - Importez votre repository GitHub
   - Vercel détectera automatiquement Vite
   - Cliquez sur "Deploy"

3. **Configuration automatique**
   - Build Command: `npm run build`
   - Output Directory: `dist`
   - Install Command: `npm install`

### Méthode 2 : Déploiement CLI Vercel

1. **Installer Vercel CLI**
   ```bash
   npm install -g vercel
   ```

2. **Se connecter à Vercel**
   ```bash
   vercel login
   ```

3. **Déployer**
   ```bash
   vercel
   ```

4. **Déployer en production**
   ```bash
   vercel --prod
   ```

## 🛠️ Développement Local

1. **Installer les dépendances**
   ```bash
   npm install
   ```

2. **Lancer le serveur de développement**
   ```bash
   npm run dev
   ```

3. **Ouvrir dans le navigateur**
   ```
   http://localhost:3000
   ```

## 📦 Build de production

```bash
npm run build
```

Les fichiers optimisés seront dans le dossier `dist/`

## 🌐 Domaine personnalisé sur Vercel

1. Allez dans les paramètres de votre projet Vercel
2. Section "Domains"
3. Ajoutez votre domaine : `app.businesshub.io`
4. Configurez les DNS selon les instructions Vercel

## 🔧 Variables d'environnement

Créez un fichier `.env.local` (non commité) :

```env
# Whop Integration
VITE_WHOP_API_KEY=your_whop_api_key_here

# Stripe
VITE_STRIPE_PUBLIC_KEY=your_stripe_public_key_here

# API Backend (optionnel)
VITE_API_URL=https://api.businesshub.io
```

Dans Vercel, ajoutez ces variables dans Settings > Environment Variables

## 📱 Fonctionnalités

- ✅ Tableau de bord en temps réel
- ✅ Finance & Trésorerie
- ✅ Assistant IA
- ✅ Recrutement intelligent
- ✅ Cybersécurité
- ✅ Formation continue
- ✅ Design responsive (mobile, tablette, desktop)

## 🔒 Sécurité

- HTTPS automatique avec Vercel
- Headers de sécurité configurés
- Protection CORS
- Authentification requise (à intégrer avec Whop)

## 📊 Performance

- Score Lighthouse : 95+
- Optimisation automatique des images
- Code splitting
- Lazy loading
- CDN global Vercel

## 🆘 Support

- Email : support@businesshub.io
- Documentation : docs.businesshub.io

## 📄 Licence

Propriétaire - BusinessHub © 2026
